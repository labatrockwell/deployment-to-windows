1. put the cygwin installer in this directory
2. run the cygwin installer on a windows computer
	* download-only mode
	* save to directory `cygwin_files`
	* select rsync
3. put `cygwin_files` in this directory
4. from the management_scripts directory run `./setup_rsync/setup_rsync.sh`